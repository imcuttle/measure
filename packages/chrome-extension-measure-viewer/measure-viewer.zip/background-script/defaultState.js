/**
 * @file defaultState
 * @author Cuttle Cong
 * @date 2018/9/23
 *
 */

module.exports = {
  smartInclude: true,
  enable: true,
  excludes: [],
  includes: []
  // includes: ['**://bos.nj.bpc-internal.baidu.com/ibox-docpreview100/**/**.psd']
}
